<script>
export default {
  onLaunch: function () {
    console.log("App Launch");
  },
  onShow: function () {
    console.log("App Show");
  },
  onHide: function () {
    console.log("App Hide");
  },
};
</script>

<style>
@import "@/static/iconfont/iconfont.css";
.page {
  padding: 15px;
  height: calc(100vh - 60px);
  overflow-y: auto;
}

.page.active {
  display: block;
}
</style>
